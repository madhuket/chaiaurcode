import express from "express";


const app = express(); // create express app

const port = process.env.PORT || 3000;

app.get("/", (req, res) => {
  res.send("Server is ready");
});

//get a list of 5 jokes
app.get("/api/jokes", (req, res) => {
  const jokes = [
      {
          id: 1,
          joke: "Why did the chicken cross the road1?",
          punchline: "To get to the other side!",
      },
      {
          id: 2,
          joke: "Why did the chicken cross the road2?",
          punchline: "To get to the other side!",
      },
      {
          id: 3,
          joke: "Why did the chicken cross the road3?",
          punchline: "To get to the other side!",
      },
      {
          id: 4,
          joke: "Why did the chicken cross the road4?",
          punchline: "To get to the other side!",
      },
      {
          id: 5,
          joke: "Why did the chicken cross the road5?",
          punchline: "To get to the other side!",
      }
  ];

  res.send(jokes);
});

app.listen(port, () => {
  console.log(`Server is running on port http://localhost:${port}`);
});
